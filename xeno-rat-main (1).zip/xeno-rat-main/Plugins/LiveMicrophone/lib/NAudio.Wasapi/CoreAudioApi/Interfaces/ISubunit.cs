﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;

namespace NAudio.CoreAudioApi.Interfaces
{
    [Guid("82149A85-DBA6-4487-86BB-EA8F7FEFCC71"),
        InterfaceType(ComInterfaceType.InterfaceIsIUnknown),
        ComImport]
    internal interface ISubunit
    {
        // Stub, Not Implemented
    }
}
